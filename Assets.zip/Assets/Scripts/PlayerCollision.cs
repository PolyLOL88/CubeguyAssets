﻿/*Copyright Poly*/
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerCollision : MonoBehaviour
{
    public float restartdelay;
    public GameObject deadUI;
    public GameObject otherscene;
    public Lives live;
    public Transform startpoint;

    private void Start()
    {
        
    }

    void OnTriggerEnter2D(Collider2D other)//Schaut nach collison
    {
        if (other.CompareTag("Enemy"))
        {
            //Der Spieler soll sterben
            live.lives -= 1;
            transform.position = startpoint.position;

        }
    }

    private void Update()
    {
        if(live.lives <= 0)
        {
            Invoke("LoadAgain", restartdelay);
        }
    }

    void LoadAgain()
    {
        deadUI.SetActive(true);
        Destroy(otherscene);
        FindObjectOfType<AudioManager>().Play("Bum");
    }
}
