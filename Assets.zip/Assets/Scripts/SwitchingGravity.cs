﻿/*Copyright Poly*/
using UnityEngine;

public class SwitchingGravity : MonoBehaviour
{
    #region Variables
    public Rigidbody2D rb;
    private bool top;
	#endregion

	#region Unity Methods

    void Update()
    {
        if (Input.GetButtonDown("Crouch"))
        {
            rb.gravityScale *= -1;
            Flip();
        }
    }

    #endregion

    void Flip()
    {
        if(top == false)
        {
            transform.eulerAngles = new Vector3(0, 0, 180f);
        }
        else
        {

            transform.eulerAngles = Vector3.zero;
        }

        top = !top;
    }
}
