﻿/*Copyright Poly*/
using UnityEngine;

public class PlayerMovemnt : MonoBehaviour
{
    private Rigidbody2D rb;
    public float speed;
    private float moveInput;
    public Transform groundcheck;
    public float checkradius;
    public GameObject sacrificesui;
    public Transform startpoint;
    public SwitchingGravity switchgrav;
    public PlayerCollision collision;
    private Animator anim;
    public BoxCollider2D collider2D;

    [SerializeField]
    LayerMask lmWalls;
    [SerializeField]
    float fJumpVelocity = 5;

    public Rigidbody2D rigid;

    float fJumpPressedRemember = 0;
    [SerializeField]
    float fJumpPressedRememberTime = 0.2f;

    float fGroundedRemember = 0;
    [SerializeField]
    float fGroundedRememberTime = 0.25f;

    [SerializeField]
    [Range(0, 1)]
    float fCutJumpHeight = 0.5f;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
    }

    void FixedUpdate()
    {
        moveInput = Input.GetAxisRaw("Horizontal");
        rb.velocity = new Vector2(moveInput * speed, rb.velocity.y);
    }

    void Update()
    {

        if(moveInput == -1)
        {
            anim.SetBool("IsRunning", true);
        }
        if (moveInput == 1)
        {
            anim.SetBool("IsRunning", true);
        }
        if (moveInput == 0)
        {
            anim.SetBool("IsRunning", false);
        }

        bool bGrounded = Physics2D.OverlapCircle(groundcheck.position, checkradius, lmWalls);

        fGroundedRemember -= Time.deltaTime;
        if (bGrounded)
        {
            fGroundedRemember = fGroundedRememberTime;
        }

        fJumpPressedRemember -= Time.deltaTime;
        if (Input.GetButtonDown("Jump"))
        {
            fJumpPressedRemember = fJumpPressedRememberTime;
        }

        if (Input.GetButtonUp("Jump"))
        {
            if (rigid.velocity.y > 0)
            {
                rigid.velocity = new Vector2(rigid.velocity.x, rigid.velocity.y * fCutJumpHeight);
            }
        }

        if ((fJumpPressedRemember > 0) && (fGroundedRemember > 0))
        {
            fJumpPressedRemember = 0;
            fGroundedRemember = 0;
            rigid.velocity = new Vector2(rigid.velocity.x, fJumpVelocity);
            FindObjectOfType<AudioManager>().Play("Jump");
        }

        if (Input.GetButtonDown("Menu"))
        {
            FindObjectOfType<AudioManager>().Play("Menu");
            sacrificesui.SetActive(true);
            Time.timeScale = 0f;
        }
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.DrawWireSphere(groundcheck.position, checkradius);
    }

    public void Increasejump()
    {
        FindObjectOfType<AudioManager>().Play("Beep");
        fJumpVelocity = 15f;
        Time.timeScale = 1f;
        transform.position = startpoint.position;
    }

    public void SwapGravityEnabled()
    {
        FindObjectOfType<AudioManager>().Play("Beep");
        switchgrav.enabled = true;
        Time.timeScale = 1f;
        transform.position = startpoint.position;
    }

    public void Turnthedeadof()
    {
        FindObjectOfType<AudioManager>().Play("Beep");
        collider2D.enabled = false;
        collision.enabled = false;
        Time.timeScale = 1f;
        transform.position = startpoint.position;
    }
}
