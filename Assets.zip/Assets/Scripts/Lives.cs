﻿/*Copyright Poly*/
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class Lives : MonoBehaviour
{
    #region Variables
    public TMP_Text livetext;
    public int lives;
    public GameObject deadUI;
    public GameObject otherscene;
	#endregion

	#region Unity Methods
    
    void Start()
    {
        
    }

    void Update()
    {
        if(lives <= 0)
        {
            Invoke("Dead", 0.1f);
        }

        livetext.text = "Lives: " + lives;
    }

    #endregion

    public void TekeDamage()
    {
        lives -= 1;
    }

    void Dead()
    {
        deadUI.SetActive(true);
        Destroy(otherscene);
        FindObjectOfType<AudioManager>().Play("Bum");
    }
}
