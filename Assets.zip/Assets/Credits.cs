﻿/*Copyright Poly*/
using UnityEngine;

public class Credits : MonoBehaviour
{
	#region Variables
	#endregion

	#region Unity Methods
    
    void Start()
    {
        
    }

    void Update()
    {
        if (Input.GetButtonDown("Crouch"))
        {
            Application.Quit();
            Debug.Log("QUIT");
        }
    }

    void FixedUpdate()
    {
    	
    }

    #endregion
}
