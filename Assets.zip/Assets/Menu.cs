﻿/*Copyright Poly*/
using UnityEngine;
using UnityEngine.SceneManagement;

public class Menu : MonoBehaviour
{
	#region Variables
	#endregion

	#region Unity Methods
    
    void Start()
    {
        
    }

    void Update()
    {
        if (Input.GetButtonDown("Jump"))
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
            FindObjectOfType<AudioManager>().Play("Beep");
        }
        if (Input.GetButtonDown("Crouch"))
        {
            Application.Quit();
        }
        if (Input.GetKeyDown(KeyCode.Tab))
        {
            SceneManager.LoadScene("Debug");
        }
    }

    void FixedUpdate()
    {
    	
    }

    #endregion
}
