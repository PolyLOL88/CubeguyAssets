﻿/*Copyright Poly*/
using UnityEngine;
using UnityEngine.SceneManagement;

public class End : MonoBehaviour
{

    #region Unity Methods

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        }
    }

    #endregion
}
